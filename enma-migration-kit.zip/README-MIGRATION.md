# ENMA — Migration & Launch Kit (No-coder Edition)

This kit helps you:
1) Migrate from CRA to **Vite + React + TypeScript**.
2) Add **PWA** basics (manifest + service worker via Vite plugin).
3) Add **IndexedDB** (Dexie) for offline storage.
4) Add **CSV import for transactions** and a stub for **ICS calendar import**.
5) Configure **Firebase Hosting** and **GitHub Actions** for one-click deploys.

> You only need to copy files and run the given commands.

---

## Step 0 — Prereqs
- Node.js 18+ and npm (or pnpm).
- A Firebase project created (go to console.firebase.google.com).

## Step 1 — Install deps
In your project root (repository folder), run:
```bash
# if you still have CRA deps around, it's fine — we'll add Vite on top
npm i -D vite @vitejs/plugin-react typescript vite-plugin-pwa
npm i dexie
# optional (calendar ICS)
npm i ical.js
```

## Step 2 — Replace / add files
Copy files from this kit into your repo, keeping structure:
- `package.json` (merge scripts if needed)
- `vite.config.ts`
- `tsconfig.json` (if you don't have one)
- `index.html` (Vite-style) — replace your CRA index.html
- `src/env.d.ts`
- `public/manifest.webmanifest` (you can change app name/icons later)
- `src/lib/db.ts` (IndexedDB via Dexie)
- `src/features/calendar/ics.ts` (ICS stub using ical.js)
- `firebase.json` and `.firebaserc` (put your project id)
- `.github/workflows/firebase-deploy.yml` (CI deploy)

## Step 3 — Minimal Vite entry
Make sure you have:
```
src/main.tsx
src/App.tsx
```
If you already have them — keep your code. Just ensure `index.html` points to `/src/main.tsx`.

## Step 4 — Env vars
Create `.env` with:
```
VITE_API_BASE=http://localhost:5173
```
Add Firebase config if you use it client-side (as `VITE_*`). Do NOT commit real secrets.

## Step 5 — Dev & build
```bash
npm run dev   # http://localhost:5173
npm run build # outputs to dist/
```

## Step 6 — Firebase Hosting
Install CLI:
```bash
npm i -g firebase-tools
firebase login
firebase use <your-project-id>
```
Check `firebase.json` rewrites (SPA). Then deploy:
```bash
firebase deploy --only hosting
```

## Step 7 — GitHub Actions (CI/CD)
- Set a repo secret: `FIREBASE_SERVICE_ACCOUNT` (JSON of a service account with Hosting Admin).
- Push to `main` → workflow builds and deploys to Firebase Hosting automatically.

---

## Storage (Dexie) quick start
```ts
import { db } from "./src/lib/db";

await db.tasks.add({ title: "New task", createdAt: new Date().toISOString() });
const all = await db.tasks.toArray();
```

## CSV import (transactions)
Parser is not included (many formats exist). For MVP, use `Papaparse` or native `FileReader` and map columns to:
```
{ date, accountId, amount, categoryId, note, isPlanned }
```

## ICS import (calendar)
See `src/features/calendar/ics.ts`. For Google Calendar, you can export ICS and import here for MVP.
Next step is OAuth sync (Google/Microsoft) on the backend.

---

## Troubleshooting
- White page after deploy → ensure `firebase.json` has SPA rewrite to `/index.html`.
- 404 on refresh → same as above.
- Type errors → run `npm run typecheck`.
- Slow dev → Node 18+, Vite runs fast; avoid huge images in `public`.

Good luck! 🚀
