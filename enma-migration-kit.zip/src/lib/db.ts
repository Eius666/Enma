import Dexie, { Table } from 'dexie'

export interface Task {
  id?: number
  title: string
  startAt?: string
  endAt?: string
  projectId?: string
  createdAt: string
}

export interface Transaction {
  id?: number
  date: string
  accountId: string
  amount: number
  categoryId?: string
  note?: string
  isPlanned?: boolean
}

export class EnmaDB extends Dexie {
  tasks!: Table<Task, number>
  transactions!: Table<Transaction, number>

  constructor() {
    super('enma-db')
    this.version(1).stores({
      tasks: '++id, title, startAt, endAt, createdAt',
      transactions: '++id, date, accountId, amount'
    })
  }
}

export const db = new EnmaDB()
