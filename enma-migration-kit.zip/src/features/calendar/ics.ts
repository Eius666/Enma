// Minimal ICS import using ical.js (installed as dependency).
// This is a stub for MVP; you can expand mapping to your data models.
import * as ICAL from 'ical.js'

export function parseICS(icsText: string) {
  const jcalData = ICAL.parse(icsText)
  const comp = new ICAL.Component(jcalData)
  const vevents = comp.getAllSubcomponents('vevent')
  return vevents.map(v => {
    const event = new ICAL.Event(v)
    return {
      uid: event.uid,
      summary: event.summary,
      start: event.startDate?.toJSDate(),
      end: event.endDate?.toJSDate(),
      location: event.location
    }
  })
}
